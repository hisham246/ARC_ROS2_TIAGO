#ifndef BIO_IK_UTILS
#define BIO_IK_UTILS
#include <tf2_eigen/tf2_eigen.h>
#include <pick_ik/goal.hpp>
#include <pick_ik/robot.hpp>

namespace teleop_utils
{
    double get_angular_distance(Eigen::Isometry3d Quat1, Eigen::Isometry3d Quat2);

    double get_linear_distance(Eigen::Isometry3d pos1, Eigen::Isometry3d pos2);

    double get_angular_movement(std::vector<double> new_position, std::vector<double> old_position);

    pick_ik::Robot get_robot(std::shared_ptr<moveit::core::RobotModel const> const& model,
                    moveit::core::JointModelGroup const* jmg,
                    std::vector<std::string> names);
}

#endif