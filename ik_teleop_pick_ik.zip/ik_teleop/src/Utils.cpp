#include <ik_teleop/Utils.h>

namespace teleop_utils
{
    double get_angular_distance(Eigen::Isometry3d Quat1, Eigen::Isometry3d Quat2)
    {
        // Get angular distances
        auto const q_1 = Eigen::Quaterniond(Quat1.rotation());
        auto const q_2 = Eigen::Quaterniond(Quat2.rotation());
        return q_2.angularDistance(q_1);
    }

    double get_linear_distance(Eigen::Isometry3d pos1, Eigen::Isometry3d pos2)
    {
        return (pos1.translation() - pos2.translation()).norm();
    }

    double get_angular_movement(std::vector<double> new_position, std::vector<double> old_position)
    {   
        double angular_movement = 0;
        for (int i = 0; i < new_position.size(); i++)
        {
            angular_movement += std::fabs(new_position[i]-old_position[i]);
        }
        return angular_movement;
    }

    pick_ik::Robot get_robot(std::shared_ptr<moveit::core::RobotModel const> const& model,
                 moveit::core::JointModelGroup const* jmg, std::vector<std::string> names)
    {
    auto robot = pick_ik::Robot{};

    // auto const& names = jmg->getActiveJointModelNames();
    auto const variable_count = names.size();

    auto minimal_displacement_divisor = 0.0;

    for (auto name : names) {
        auto const& bounds = model->getVariableBounds(name);

        auto var = pick_ik::Robot::Variable{};

        var.bounded = bounds.position_bounded_;
        var.min = bounds.min_position_;
        var.max = bounds.max_position_;
        var.mid = 0.5 * (var.min + var.max);
        var.half_span = var.bounded ? (var.max - var.min) / 2.0 : M_PI;

        auto const max_velocity = bounds.max_velocity_;
        var.max_velocity_rcp = max_velocity > 0.0 ? 1.0 / max_velocity : 0.0;

        var.minimal_displacement_factor = 1.0 / static_cast<double>(variable_count);
        minimal_displacement_divisor += var.max_velocity_rcp;

        robot.variables.push_back(var);
    }

    // Calculate minimal displacement factors
    if (minimal_displacement_divisor > 0) {
        for (auto& var : robot.variables) {
            var.minimal_displacement_factor = var.max_velocity_rcp / minimal_displacement_divisor;
        }
    }

    return robot;
}
}
