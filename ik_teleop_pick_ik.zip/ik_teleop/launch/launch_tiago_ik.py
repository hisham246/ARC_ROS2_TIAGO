import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    ld = LaunchDescription()
    config_control_node = os.path.join(
        get_package_share_directory('ik_teleop'),
        'config',
        'tiago_bio_ik_teleop.yaml'
        )
        
    control_node=Node(
        package = 'ik_teleop',
        name = 'IK_control_node',
        executable = 'control_node',
        parameters = [config_control_node]
    )

    config_bridge = os.path.join(
        get_package_share_directory('ik_teleop'),
        'config',
        'tiago_bridge.yaml'
        )
        
    bridge_node=Node(
        package = 'ik_teleop',
        name = 'teleop_bridge',
        executable = 'teleop_msg_bridge',
        parameters = [config_bridge]
    )

    ld.add_action(control_node)
    ld.add_action(bridge_node)


    return ld